unlink $TEST . ".tif";
unlink $TEST . ".opts";
